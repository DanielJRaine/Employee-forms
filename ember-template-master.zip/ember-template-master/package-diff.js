{
  "devDependencies": {    
    "ember-cli-shims": "^1.0.2",
    "ember-source": "^2.11.0",
    "ember-welcome-page": "^2.0.2",
  },
}
